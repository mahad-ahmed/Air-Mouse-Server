Air Mouse (v5.0.1)


------------------------------
	Installation
------------------------------
No installation is required, the executable is standalone and portable.

Windows will probably show a big scary window saying "Windows protected your PC" the 
first time you run the application;
This is because as a standalone developer I cannot afford the ridiculous 
per year cost (400 - 700USD) for a digital certificate.

Just click on 'More info' and 'Run anyway'

If application is not run as 'Administrator', it will lose control over elevated 
processes such as 'Task Manager' but should work fine otherwise

Ensure the PC on the same network as the Android device

Ensure Firewall isn't blocking the application



-------------------------------
	Compatibility
-------------------------------
This version should be compatible with Android app version 5.X.X



-------------------------------
	Issues & bugs
-------------------------------
Should you find/wish to report any issues, bugs or complains;
Email me at: atompunkapps@gmail.com




Note: If you somehow managed to find this executable without knowing about the Android 
application that it pairs with, here's a link to the app:
- https://play.google.com/store/apps/details?id=com.bytasaur.airmouse
